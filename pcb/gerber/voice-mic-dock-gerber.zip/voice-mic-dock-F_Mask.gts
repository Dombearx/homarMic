%TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*%
%TF.CreationDate,2026-11-09T22:08:17+00:00*%
%TF.ProjectId,voice-mic-dock,766f6963-652d-46d6-9963-2d646f636b2e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-11-09 22:08:17*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250001X-0.799999X-0.799999X0.799999X-0.799999X0.799999X0.799999X-0.799999X0.799999X0*%
%ADD11C,2.200000*%
%ADD12C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,J2*%
X20500000Y-9000000D03*
%TD*%
D11*
%TO.C,H2*%
X33500000Y-3500000D03*
%TD*%
D12*
%TO.C,P1*%
X8600000Y-5000000D03*
X27400000Y-5000000D03*
%TD*%
D10*
%TO.C,J1*%
X15500000Y-9000000D03*
%TD*%
D11*
%TO.C,H1*%
X2500000Y-3500000D03*
%TD*%
M02*
